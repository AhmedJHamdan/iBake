package com.example.ahmed.ibake.Database;

public class RecipeDB {

    public static final String DB_NAME = "recipe";
    public static final int DB_VERSION = 1;
}