package com.example.ahmed.ibake.Database;

import android.content.Context;

public class RecipeDaoHelper extends DaoMaster.OpenHelper {

    public RecipeDaoHelper(Context context, String name) {
        super(context, name);
    }
}
